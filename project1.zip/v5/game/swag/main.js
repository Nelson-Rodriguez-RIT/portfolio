// Environment setup
const canvas = document.querySelector('canvas');
const ctx = canvas.getContext('2d');

canvas.width = 1024;
canvas.height = 576;
ctx.scale(2, 2);

// Maintains a pixalated look
ctx.imageSmoothingEnabled = false;
canvas.style.imageRendering = "pixelated";



var Deltatime    = 0;
let currentTime  = 0;
let previousTime = 0;


var User = {};

const CONFIG = {
    animation_fps: 60,
};

const ASSETS = {
    ice_mage: { 
        image:  null, 
        url:    "./assets/ice_mage.png",

        spritesheet: { w: 576, h: 512 },
        sprite:      { w: 64, h: 64 }, 
        offset:      { x: 0, y: 0 },
    },
};

const KEYFRAMES = {
    mage: [
        [10, 20, 30, 40, 50],                   // Idle
        [10, 20, 30, 40, 50],                   // Idle Air
        [6, 12, 18, 24],                        // Walk
        [6, 12, 18, 24, 30, 36, 42, 48],        // Walk Air
        [1],                                    // Hitstun
        [3, 6, 9, 12, 25],                      // Death/Teleport
        [6, 12, 18, 24, 30, 36, 42, 48, 52],    // Attack
        [6, 12, 18, 24, 30, 36, 42, 48, 52],    // Attack Air
    ]
}







// Used to load external assets
function load() {
    ASSETS.ice_mage.image = new Image(ASSETS.ice_mage.spritesheet.w, ASSETS.ice_mage.spritesheet.h);
    ASSETS.ice_mage.image.src = ASSETS.ice_mage.url;

    init();
}


// Prepares the game environment
function init() {
    User = new GameObject({
        position_vector: new Vector3({primatives: {x: 20, y: 0, z: 20}}),
        sprite: new Sprite({asset: ASSETS.ice_mage, keyframes: KEYFRAMES.mage}),
    })

    User.acceleration.x = 2;

    update();
}


// Called every frame after load() and init() have finished their business 
function update() {
    // Queue this function to be called again next frame
    window.requestAnimationFrame(update);

    // Update deltatime
    currentTime = window.performance.now();
    Deltatime = (currentTime - previousTime) / 1000; // These means that if deltatime was cumulative it would equal 1 after 1 second
    previousTime = currentTime;

    // Set background
    ctx.fillStyle = 'rgb(36, 36, 36)';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    User.update();
    User.draw();
}







class Sprite {
/*
    USAGE

    Sprite's have 3 sets of functionality:

    "this.animate = false"      [Requires] An image, sprite dimensions, and an offset (can be 0, but has to be defined at least)
        Displays a static image sourced from the over spritesheet

    "this.animate = true"       [Requires] The above and sets of keyframes
        Goes through the image and changes the sourced sprite used based on keyframes.
        NOTE:   Assumes that frames for an animation are layed out horizontally,
                with an entire animations be layed out vertically

    
    "this.script = function"    [Requires] One of the above to fufilled and must be manually set
        Does the above, but will also call this script function with respecitive Sprite object being passed as a param. Allows for more
        control over how the sprite is displayed by directly changing values such as this.timer, this.spriteSet, and/or this.spriteFrame.
        Additionally, animation data can be stored for further use via this.cache
    
*/

    constructor({asset, keyframes, animate = true}) {
        // Base data required to display anything
        this.image  = asset.image;
        this.offset = asset.offset;
        this.sprite = asset.sprite;

        // Functionality control
        this.animate = animate;

        // Animation control
        this.keyframes = keyframes;

        this.spriteSet      = 0; // Determines index of the current animation i.e. walk, run, attack
        this.spriteFrame    = 0; // Determines the index of the sprite within the animation i.e. 1st sprite, 2nd sprite, etc
        this.timer          = 0; // Keeps track of when to update to the next sprite in the spriteSet (or to restart the animation if finished)

        // Used, mainly, to interact with keyframes in a specifc way. This should be set manually when needed
        // i.e. teleport uses the death animation twice, playing it backwards a second time while also skipping the first frame both times
        this.script = null;    // Scripts, when called, are passed this entire object as a parem
        this.cache  = {};      // For scripts to store data
        
    }

    draw(position_vector) {
        if (this.animate) {
            let keyframeFinal = this.keyframes[this.spriteSet][this.keyframes[this.spriteSet].length - 1];

            // Update animation timer
            if ((this.timer += Deltatime * CONFIG.animation_fps) >= keyframeFinal)
                this.timer = 0;

            // Set spriteframe based on animation timer
            this.spriteFrame = 0;
            this.keyframes[this.spriteSet].forEach(
                (keyframe) => { if (this.timer >= keyframe) this.spriteFrame++; });

        }

        if (this.script != null)
            this.script(this);

        ctx.drawImage(
            // Sprite sheet
            this.image,

            // Offset before extracting image
            this.offset.x + (this.spriteFrame * this.sprite.w),
            this.offset.y + (this.spriteSet   * this.sprite.h),

            // Extracted image size
            this.sprite.w, 
            this.sprite.h,

            // Final image position
            position_vector.x,
            (position_vector.z != undefined ? position_vector.z : 0) - position_vector.y,

            // Final image size
            this.sprite.w, 
            this.sprite.h,
        );
    }

    
}

class GameObject {
    constructor({
        position_vector = new Vector3({x: 0, y: 0, z: 0}), 
        sprite = null, 
        physics = {
            enableFriction:                 false,
            frictionStregnth:               0,

            enableGravity:                  false,
            weight:                         0,

            enableWallBounce:               false,
            wallBounceVelocityThreshold:    0,

            enableGroundBounce:             false,
            groundBounceVelocityThreshold:  0,

            enableTerrainCollision:         false,
            enableNonTerrainCollision:      false,
        }}
    ) {
        this.position     = position_vector;
        this.velocity     = new Vector3({x: 0, y: 0, z: 0});
        this.acceleration = new Vector3({x: 0, y: 0, z: 0});

        // Physics flags
        this.isGrounded = true;
        this.physics = physics;


        this.sprite = sprite;
    }

    update() {
        // Additional physics updated based on set flags
        if (this.enableFriction && this.isGrounded) {

        }

        if (this.enableGravity && !this.isGrounded) {

        }

        if (this.enableWallBounce || this.enableGroundBounce) {
            // TODO: This
        }

        if (this.enableTerrainCollision || this.enableNonTerrainCollision) {
            // TODO: This
        }


        // Last to give physics logic a chance to modify values accuratly (i.e. collision)
        this.velocity.add({vector: Vector3.multiply({vector1: this.acceleration, value: Deltatime})})
        this.position.add({vector: Vector3.multiply({vector1: this.velocity, value: Deltatime})})
    }

    draw() {
        if (this.sprite != null) this.sprite.draw(this.position);
    }
}

// For my convience:
// new Vector3({x: 0, y: 0, z: 0});
class Vector3 {
    constructor({primatives = {x: 0, y: 0, z: 0}, vector3 = null}) {
        if (vector3) {
            this.x = vector3.x;
            this.y = vector3.y;
            this.z = vector3.z;
        }
        else {
            this.x = primatives.x;
            this.y = primatives.y;
            this.z = primatives.z;
        }
    }

    magnitude() {
        return Math.sqrt(Math.pow(this.x, 2) + Math.pow(this.y, 2) + Math.pow(this.z, 2));
    }

    normalize() {
        let mag = this.magnitude();
        return new Vector3({primatives: {x: this.x / mag, y: this.y / mag, z: this.z / mag}});
    }


    static add({vector1, vector2 = null, value = null}) {
        return new Vector3({
            primatives: {
                x: vector1.x + (vector2 ? vector2.x : 0) + (value ? value : 0), 
                y: vector1.y + (vector2 ? vector2.y : 0) + (value ? value : 0), 
                z: vector1.z + (vector2 ? vector2.z : 0) + (value ? value : 0)
            }
        })
    }

    static subtract({vector1, vector2 = null, value = null}) {
        return new Vector3({
            primatives: {
                x: vector1.x - (vector2 ? vector2.x : 0) - (value ? value : 0), 
                y: vector1.y - (vector2 ? vector2.y : 0) - (value ? value : 0), 
                z: vector1.z - (vector2 ? vector2.z : 0) - (value ? value : 0)
            }
        })
    }

    static multiply({vector1, vector2 = null, value = null}) {
        return new Vector3({
            primatives: {
                x: vector1.x * (vector2 ? vector2.x : 1) * (value ? value : 1), 
                y: vector1.y * (vector2 ? vector2.y : 1) * (value ? value : 1), 
                z: vector1.z * (vector2 ? vector2.z : 1) * (value ? value : 1)
            }
        })
    }

    static divide({vector1, vector2 = null, value = null}) {
        return new Vector3({
            primatives: {
                x: vector1.x / (vector2 && vector2.x != 0 ? vector2.x : 1) / (value && value != 0 ? value : 1), 
                y: vector1.y / (vector2 && vector2.y != 0 ? vector2.y : 1) / (value && value != 0 ? value : 1),
                z: vector1.z / (vector2 && vector2.z != 0 ? vector2.z : 1) / (value && value != 0 ? value : 1) 
            }
        })
    }


    add({vector = null, value = null}) {
        if (vector) {
            this.x += vector.x;
            this.y += vector.y;
            this.z += vector.z;
        }

        if (value){
            this.x += value;
            this.y += value;
            this.z += value;
        }
    }

    
    subtract({vector = null, value = null}) {
        if (vector) {
            this.x -= vector.x;
            this.y -= vector.y;
            this.z -= vector.z;
        }

        if (value){
            this.x -= value;
            this.y -= value;
            this.z -= value;
        }
    }

    
    multiply({vector = null, value = null}) {
        if (vector) {
            this.x *= vector.x;
            this.y *= vector.y;
            this.z *= vector.z;
        }

        if (value){
            this.x *= value;
            this.y *= value;
            this.z *= value;
        }
    }

    
    divide({vector = null, value = null}) {
        if (vector) {
            this.x /= (vector.x != 0 ? vector.z : 1);
            this.y /= (vector.y != 0 ? vector.z : 1);
            this.z /= (vector.z != 0 ? vector.z : 1);
        }

        if (value){
            this.x /= value;
            this.y /= value;
            this.z /= value;
        }
    }
}






load();